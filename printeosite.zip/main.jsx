import React from "react"
import ReactDOM from "react-dom/client"
import Home from "./Home"
import "./style.css"

// Make sure the DOM is fully loaded before rendering
document.addEventListener("DOMContentLoaded", () => {
  const rootElement = document.getElementById("root")

  if (rootElement) {
    ReactDOM.createRoot(rootElement).render(
      <React.StrictMode>
        <Home />
      </React.StrictMode>,
    )
  } else {
    console.error("Could not find root element to mount React app")
  }
})
