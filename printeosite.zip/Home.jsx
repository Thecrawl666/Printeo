"use client"

import { useState } from "react"

export default function Home() {
  const [weight, setWeight] = useState(0)
  const [time, setTime] = useState(0)
  const [price, setPrice] = useState(0)

  const handleEstimate = () => {
    const materialCost = weight * 0.04 // €/g
    const timeCost = time * 1.2 // €/h
    const total = (materialCost + timeCost).toFixed(2)
    setPrice(total)
  }

  return (
    <main style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1 style={{ textAlign: "center" }}>Printéo - Impression 3D Personnalisée</h1>
      <div style={{ maxWidth: "600px", margin: "2rem auto" }}>
        <p>Upload ton fichier STL et reçois une estimation immédiate :</p>
        <input type="file" accept=".stl" />
        <input
          type="number"
          placeholder="Poids estimé (g)"
          onChange={(e) => setWeight(Number.parseFloat(e.target.value))}
          style={{ display: "block", margin: "1rem 0", width: "100%" }}
        />
        <input
          type="number"
          placeholder="Temps d'impression estimé (h)"
          onChange={(e) => setTime(Number.parseFloat(e.target.value))}
          style={{ display: "block", margin: "1rem 0", width: "100%" }}
        />
        <textarea placeholder="Détails du projet" style={{ display: "block", width: "100%", marginBottom: "1rem" }} />
        <input
          type="email"
          placeholder="Ton e-mail ou Insta"
          style={{ display: "block", width: "100%", marginBottom: "1rem" }}
        />
        <button onClick={handleEstimate}>Estimer le prix</button>
        {price > 0 && <p style={{ marginTop: "1rem" }}>Estimation : {price} €</p>}
      </div>
    </main>
  )
}
